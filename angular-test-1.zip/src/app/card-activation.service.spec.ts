import { TestBed } from '@angular/core/testing';

import { CardActivationService } from './card-activation.service';

describe('CardActivationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CardActivationService = TestBed.get(CardActivationService);
    expect(service).toBeTruthy();
  });
});
