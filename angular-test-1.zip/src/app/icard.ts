export interface Icard {
    name: string,
    isActive: boolean
}
