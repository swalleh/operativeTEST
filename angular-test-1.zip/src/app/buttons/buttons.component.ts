import { Component, OnInit, Input } from '@angular/core';
import { CardActivationService } from '../card-activation.service';
import { Icard } from '../icard';

@Component({
  selector: 'app-buttons',
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.scss']
})
export class ButtonsComponent implements OnInit {

  constructor(private cardActivationService: CardActivationService) { }
  cardList: Icard[];
  @Input() componentNumber: number = 0;
  ngOnInit() {

    this.cardActivationService.cards.subscribe(x => {
      this.cardList = x;
    });
  }

  removeCard(cardName) {
    this.cardList.forEach(x => {
      if (cardName == x.name) {
        x.isActive = false;
      }
    });

    this.cardActivationService.cards.next(
      this.cardList
    )
  }

}
