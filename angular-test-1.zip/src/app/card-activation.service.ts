import { Injectable } from '@angular/core';
import { Icard } from './icard';
import { Subject, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CardActivationService {
  public cards = new BehaviorSubject<Icard[]>(
    [
      {
        isActive: true,
        name: "c1"
      },
      {
        isActive: true,
        name: "c2"
      },
      {
        isActive: true,
        name: "c3"
      },
      {
        isActive: true,
        name: "c4"
      },
    ]
  );

  constructor() { }
}
