import { Component, OnInit } from '@angular/core';
import { CardActivationService } from './card-activation.service';
import { Icard } from './icard';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'AngularTest1';
  constructor(private cardActivationService: CardActivationService) { }
  cards: Icard[];

  ngOnInit() {
    this.cardActivationService.cards.subscribe(x => {
      this.cards = x;
    });
  }
}
